import "./App.css";
import { useState } from "react";

export default function App() {
  const [todolist, updatetodolist] = useState(['create-app', 'npm start']);
  const [newTodo, setNewTodo] = useState('');
  const [isFocus, setFocus] = useState('');
  const [currentVal, setCurrentVal] = useState('');
  const [selectedCheckbox, setSelectedCheckbox] = useState('');

  const onClickSave = () => {
    const newTodolist = [...todolist];
    newTodolist.push(newTodo);
    updatetodolist(newTodolist);
    setNewTodo('');
  };

  const onChangeNewTodo = (e) => {
    const val = e.target.value;
    setNewTodo(val);
  }

  const changeVal = (ind) => {
    const newlist = [...todolist]
    newlist[ind] = currentVal;
    updatetodolist(newlist)
  }

  const removeFromList = (indx) => {
    const newlist = [...todolist]
    newlist.splice(indx, 1);
    updatetodolist(newlist);
    setSelectedCheckbox('');
  }

  const updatedCheckbox = (idx) => {
    if(selectedCheckbox === idx) {
      setSelectedCheckbox('');
    } else {
      setSelectedCheckbox(idx);
    }
  }

  return (
    <div className="App">
      <h1>My Todo's</h1>
      <div>
        <div>
          <input className="addlistinput" value={newTodo} onChange={(e) => onChangeNewTodo(e)}/>
          <button className="save-button" onClick={onClickSave}>save</button>
        </div>
        <div className="list-container">
          {todolist.map((note, index) => {
            return (
              <div key={index} className="item-container">
                <div>
                  <input type="checkbox" onClick={() => {updatedCheckbox(index)}} checked={index === selectedCheckbox}/>
                </div>
                <div className="todo-label">
                  <p
                     contentEditable="true"
                     title={note}
                     onFocus={() =>{ setFocus(index); setCurrentVal(note);}}
                     onChange={(e) => setCurrentVal(e.target.value)}
                     onBlur={() => setFocus('')}
                     >
                      {note}
                  </p>
                  {(isFocus === index) && 
                    <button className="save-button" onClick={() => { changeVal(index)}}>save</button>
                  }
                </div>
                <div>
                  <button className="remove-button" onClick={() => removeFromList(index)}>Remove</button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
