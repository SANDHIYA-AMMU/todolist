import { PUBLISH_LIST_FAILURE, PUBLISH_LIST_SUCCESS } from "./actionTypes/todoListActions.js";

import axios from 'axios';

export const publishList = (todoList) => async dispatch => {
    
    try{
        const url = "https://jsonplaceholder.typicode.com/posts"
        const res = await axios.post(url,{
            list: todoList
        });
        console.log(res);
        dispatch( {
            type: PUBLISH_LIST_SUCCESS,
            payload: res,
        })
    }
    catch(e){
        dispatch( {
            type: PUBLISH_LIST_FAILURE,
            payload: e,
        })
    }

}

export default publishList;