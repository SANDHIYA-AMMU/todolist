import { createStore, applyMiddleware } from 'redux';
import todoListReducer from './reducer/todoListReducer.js';
import {composeWithDevTools} from 'redux-devtools-extension';
import thunk from 'redux-thunk';


export default function configureStore(initialState) {
    const middleware = [thunk];
    return createStore(todoListReducer, initialState, composeWithDevTools(applyMiddleware(...middleware)) );
}