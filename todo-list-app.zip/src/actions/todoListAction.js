import * as actionTypes from "../actionTypes/todoListActions.js";

export const updatetodolist = (list) => {
  return {
    type: actionTypes.UPDATE_TODO_LIST,
    list
  }  
};

export const setSelectedCheckbox = (status) => {
  return {
    type: actionTypes.TOGGLE_CHECKBOX,
    status
  }  
};
