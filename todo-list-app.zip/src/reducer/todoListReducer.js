import {
    PUBLISH_LIST_FAILURE,
    PUBLISH_LIST_SUCCESS,
    TOGGLE_CHECKBOX,
    UPDATE_TODO_LIST
} from '../actionTypes/todoListActions.js';
import { toast } from 'react-toastify';

const initialState = {
    todolist: [],
    selectedCheckbox: ''
}
export default function todolistReducer (state = initialState, action){
    switch(action.type){
        case UPDATE_TODO_LIST:
            const { list } = action;

            return {
                ...state,
                todolist: list
            };
        
        case TOGGLE_CHECKBOX:
            const { status } = action;

            return {
                ...state,
                selectedCheckbox: status
            };

        case PUBLISH_LIST_SUCCESS:
            toast.success("Published List Successfully");
            break;

        case PUBLISH_LIST_FAILURE:
            toast.error('Error!!!');
            break;

        default: 
            return {
                ...state
            };
    }

}