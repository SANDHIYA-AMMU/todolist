import { useState,  } from "react";
import { connect, useDispatch } from "react-redux";
import { bindActionCreators } from "redux";
import * as todoAction from "./actions/todoListAction.js";
import { publishList } from "./apiActions.js";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css'; 

import "./App.css";

export const App = (props) => {
  const { actions, todolist, selectedCheckbox } = props;
  const dispatch = useDispatch();
  const [newTodo, setNewTodo] = useState('');
  const [isFocus, setFocus] = useState('');
  const [currentVal, setCurrentVal] = useState('');

  const onsubmitList = () => {
    dispatch(publishList(todolist));
  }

  const onClickSave = () => {
    const newTodolist = [...todolist];
    newTodolist.push(newTodo);
    actions.updatetodolist(newTodolist);
    setNewTodo('');
  };

  const onChangeNewTodo = (e) => {
    const val = e.target.value;
    setNewTodo(val);
  }

  const changeVal = (ind) => {
    const newlist = [...todolist]
    newlist[ind] = currentVal;
    actions.updatetodolist(newlist)
  }

  const removeFromList = (indx) => {
    const newlist = [...todolist]
    newlist.splice(indx, 1);
    actions.updatetodolist(newlist);
    actions.setSelectedCheckbox('');
  }

  const updatedCheckbox = (idx) => {
    if(selectedCheckbox === idx) {
      actions.setSelectedCheckbox('');
    } else {
      actions.setSelectedCheckbox(idx);
    }
  }

  return (
    <div className="App">
      <h1>My Todo's</h1>
      <div>
        <div>
          <input className="addlistinput" value={newTodo} onChange={(e) => onChangeNewTodo(e)}/>
          <button className="save-button" onClick={onClickSave}>save</button>
        </div>
        <div className="list-container">
          {todolist.map((note, index) => {
            return (
              <div key={index} className="item-container">
                <div>
                  <input type="checkbox" onChange={() => {updatedCheckbox(index)}} checked={index === selectedCheckbox}/>
                </div>
                <div className="todo-label">
                  <p
                     contentEditable="true"
                     title={note}
                     onFocus={() =>{ setFocus(index); setCurrentVal(note);}}
                     onChange={(e) => setCurrentVal(e.target.value)}
                     onBlur={() => setFocus('')}
                     >
                      {note}
                  </p>
                  {(isFocus === index) && 
                    <button className="save-button" onClick={() => { changeVal(index)}}>save</button>
                  }
                </div>
                <div>
                  <button className="remove-button" onClick={() => removeFromList(index)}>Remove</button>
                </div>
              </div>
            );
          })}
        </div>
        <div>
          <button className="submit-btn" type="button" onClick={() => onsubmitList()}>Submit</button>
        </div>
      </div>
      <ToastContainer />
    </div>
  );
}

const mapDispatchToProps = (dispatch) => ({
  actions: bindActionCreators(todoAction, dispatch),
});

const mapStateToProps = (state) => {
  return {
    todolist: state.todolist ? state.todolist : [],
    selectedCheckbox: state.selectedCheckbox ? state.selectedCheckbox : '',
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(App);
